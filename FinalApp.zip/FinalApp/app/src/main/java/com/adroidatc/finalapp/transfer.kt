package com.adroidatc.finalapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class transfer : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_transfer)
    }
}