package com.adroidatc.finalapp

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_deposit.*
import kotlinx.android.synthetic.main.activity_second.*

class deposit : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_deposit)

        var userInput = userDeposit

        dButton.setOnClickListener {
            var total = userInput.toString().toLong() + checkingAmount.toString().toLong()
            onBackPressed()
            Intent(this,SecondActivity::class.java).also {
                it.putExtra("+$100", total)
                startActivity(it)
            }
        }


    }
}