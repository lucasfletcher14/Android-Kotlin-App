package com.adroidatc.finalapp

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*
import java.math.BigDecimal
import java.math.RoundingMode
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        loginButton.setOnClickListener {
            val fname = fnameInput.text.toString()
            val lname = lnameInput.text.toString()
            val randomNum1 = Random.nextDouble(1001.00)
            val bd = BigDecimal(randomNum1)
            val randomChecking = bd.setScale(2, RoundingMode.UP).toDouble()
            val randomNum2 = Random.nextDouble(1001.00)
            val bd2 = BigDecimal(randomNum2)
            val randomSaving = bd2.setScale(2, RoundingMode.UP).toDouble()
            Intent(this, SecondActivity::class.java).also {
                it.putExtra("RANDOM_CHECKING", randomChecking)
                it.putExtra("RANDOM_SAVING", randomSaving)
                it.putExtra("FIRST_NAME", fname)
                it.putExtra("LAST_NAME", lname)
                startActivity(it)
            }
        }

        helpButton.setOnClickListener{
            Intent(this, HelpActivity::class.java).also {
                startActivity(it)
            }
        }


    }
}
