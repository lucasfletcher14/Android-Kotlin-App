package com.adroidatc.finalapp

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import kotlinx.android.synthetic.main.activity_second.*

class SecondActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        val firstname = intent.getStringExtra("FIRST_NAME")
        val lastName = intent.getStringExtra("LAST_NAME")
        val checking = intent.getDoubleExtra("RANDOM_CHECKING", 200.00)
        val saving = intent.getDoubleExtra("RANDOM_SAVING", 400.00)
        val userDeposit1 = intent.getStringExtra("+$100")
        val welcomeMessage = "Hello $firstname $lastName! Welcome to your account."


        var checkingAmount = findViewById<TextView>(R.id.checkingAmount)
        checkingAmount.text = userDeposit1

        accountLabel.text = welcomeMessage
        checkingAmount.text = "$$checking"
        savingAmount.text = "$$saving"



        var savingAmount = findViewById<TextView>(R.id.savingAmount)
        var depositButton = findViewById<Button>(R.id.depositButton)
        var withdrawButton = findViewById<Button>(R.id.withdrawButton)
        var transferButton = findViewById<Button>(R.id.transferButton)


        depositButton.setOnClickListener {
            val intent = Intent(this, deposit::class.java)
            startActivity(intent)
        }
        withdrawButton.setOnClickListener {
            val intent = Intent(this, withdraw::class.java)
            startActivity(intent)
        }
        transferButton.setOnClickListener {
            val intent = Intent(this, transfer::class.java)
            startActivity(intent)
        }

        val appSettingPrefs: SharedPreferences = getSharedPreferences("AppSettingPrefs", 0)
        val sharedPrefsEdit: SharedPreferences.Editor = appSettingPrefs.edit()
        val isNightModeOn: Boolean = appSettingPrefs.getBoolean("NightMode", false)

        if (isNightModeOn) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }

        darkModeBtn.setOnClickListener {
            if (isNightModeOn) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                sharedPrefsEdit.putBoolean("NightMode", false)
                sharedPrefsEdit.apply()
            } else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                sharedPrefsEdit.putBoolean("NightMode", true)
                sharedPrefsEdit.apply()
            }

        }

    }

}